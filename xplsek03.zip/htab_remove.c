// htab_remove.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include "htab.h"

bool htab_remove(struct htab_t * t, char * key) { // find item and return bool 0/1	
	unsigned int index = (htab_hash_function(key) % MAGIC);
	struct htab_listitem * curr = t->arr_size[index]; // this is ptr where we start
	struct htab_listitem * curr_prev = curr; // set previous item to default
		
		if(!strcmp(curr->key,key)) {// test if item is not first on line, thats specific situation in my case: BUGGY
			curr->key = curr->next->key;
			curr->data = curr->next->data;
			curr->next = curr->next->next;
			free(curr->key);
			free(curr);
			t->arr_size[index] = NULL;
			return true;
		}	
		while(curr != NULL) { // while is not found on line			
			if(!strcmp(curr->key,key)) { // found item in list				
				if(curr->next == NULL) // if item is last on line
					curr_prev->next = NULL;
				else
					curr_prev = curr->next; // ommit. item
				free(curr->key);
				free(curr);
				t->size-=1; // size--
				return true;
			}			
			curr_prev = curr;
			curr = curr->next;
		}
			return false; // not found on line
}