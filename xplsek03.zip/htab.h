// htab.h
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdbool.h>
#define MAGIC 46663u //hledame velke prvocislo: duvod - rovnomerne rozdeleni prvku do radku + vyhnout se kolizim. u = unsigned. (optimal =~ 75% of table size.?)
#define LIMIT 127 // limit to one line

struct htab_listitem { // enlisted element
char *key; // dyn alloc string 
unsigned int data; // count
struct htab_listitem *next; // point to next, otherwise null
};
struct htab_t { // hash table
unsigned long size;
struct htab_listitem *arr_size[]; // flexible array member
};

struct htab_t * htab_move(unsigned int newsize, struct htab_t * t2);								  
unsigned long htab_bucket_count(struct htab_t * t);
void htab_clear(struct htab_t * t);
struct htab_listitem * htab_find(struct htab_t *t, const char *key);
void htab_foreach(struct htab_t * t, void (*func)(struct htab_listitem * curr));
void htab_free(struct htab_t * t);
unsigned int htab_hash_function(const char *str);
struct htab_t * htab_init(unsigned int size);
struct htab_listitem * htab_lookup_add(struct htab_t *t, const char *key);
bool htab_remove(struct htab_t * t, char * key);
unsigned long htab_size(struct htab_t * t);