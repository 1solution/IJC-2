// htab_move.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include "htab.h"

struct htab_t * htab_move(unsigned int newsize, struct htab_t * t2) { // move hash table t2 to newly created hash table, then delete contents of t2
	struct htab_t * new_hash = htab_init(newsize); // new hash table
	if(new_hash == NULL) // bad alloc
		return NULL;		
	for(unsigned int i = 0; i < MAGIC; i++) {
		struct htab_listitem * curr = t2->arr_size[i];
		struct htab_listitem * curr_new = new_hash->arr_size[i];
		if(curr != NULL) { // if base ptr is not null
			curr_new = htab_lookup_add(new_hash,t2->arr_size[i]->key); // adding item to base ptr
			curr_new->data = curr->data;
				while(curr->next != NULL) {
						struct htab_listitem * curr_next = curr->next;
						struct htab_listitem * curr_next_new = htab_lookup_add(new_hash,curr_next->key);
						curr_new->next = curr_next_new;						// connect items
						curr_new = curr_next_new;
						curr_new->data = curr->data;
						curr = curr_next;
					}				
				curr_new->next = NULL; // apply function for last item in line
		}
	}
	
	htab_clear(t2);
	return new_hash;
}