// htab_lookup_add.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "htab.h"

struct htab_listitem * htab_lookup_add(struct htab_t *t, const char *key) { // search in table for item, if not found add it 
  unsigned int index = (htab_hash_function(key) % MAGIC);
  bool eol = false; // end of line switch
  struct htab_listitem * curr = t->arr_size[index];
  if(curr != NULL) {  // if there is a list on ptr, go through it
    while(1) { 
      if(!strcmp(curr->key,key)) { // if key is same
        curr->data+=1;
        return curr;
      }
      if(curr->next == NULL) // end of list..
        break;     
      curr = curr->next;
    }
	eol = true; // ok, in next step add it to end of list..
  } 
	struct htab_listitem *new_it = malloc(sizeof(*new_it));  // creating new item if to base ptr
	new_it->key = (char*)malloc(strlen(key)+1);
	if(new_it == NULL)
			return NULL;
  	strcpy(new_it->key,key);
    new_it->data = 1;
    new_it->next = NULL;
	t->size+=1; // size++
    
	if(eol) {
		curr->next = new_it; // adding to end of list
		return new_it;
	}
	else {
		t->arr_size[index] = new_it; // adding to base pointer
		return new_it; 
	}
}