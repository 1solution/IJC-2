// io.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <ctype.h>

int get_word(char *s, int max, FILE *f) { // read word by word from file (in our case stdin)
  unsigned short counter = 0;
	
	int c = 0;
	
  while(!isspace(c = fgetc(f))) {
	if(c == EOF)
		return EOF;
	
	if(counter == max-1) { // reached limit, goto is faster than if
	  goto reached_limit;
    }
    s[counter] = c;
    counter++;
  }
  
  reached_limit:
  if(counter == max-1) { // if reached limit
		if(!isspace(c = fgetc(f))) { // waste other chars
			while(!isspace(fgetc(f)) && c != EOF)
				c = fgetc(f);
		}
	return LIMIT+1;
  } 

  return counter;  
}