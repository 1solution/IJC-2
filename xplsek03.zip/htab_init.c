// htab_init.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include "htab.h"

struct htab_t * htab_init(unsigned int size) { // init table
struct htab_t *hash = malloc(size * sizeof(struct htab_listitem) + sizeof(*hash)); // sizeof(int) for size of table = arr_size[]
if(hash == NULL) // bad alloc
  return NULL;
else {
  hash->size = 0; // set size to number of elements, eq. 0 for now
  for(unsigned int i = 0; i < size; i++ )// NULL ptrs to arr_size elements
	hash->arr_size[i] = NULL;
  }
  return hash;
}