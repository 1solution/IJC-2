// htab_foreach.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include "htab.h"

void htab_foreach(struct htab_t * t, void (*func)(struct htab_listitem * curr)) { // apply func for every item in hash table
	for(unsigned int i = 0; i < MAGIC; i++) {
		struct htab_listitem * curr = t->arr_size[i];		
		if(curr != NULL) {
			while(curr->next != NULL) {
				struct htab_listitem * curr_next = curr->next;
				func(curr); // apply function on item
				curr = curr_next;
			}
			func(curr); // apply function for last item in line
		}
	}	
}