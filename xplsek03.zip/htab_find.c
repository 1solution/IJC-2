// htab_find.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <string.h>
#include "htab.h"

struct htab_listitem * htab_find(struct htab_t *t, const char *key) { // find item in line, if not find returns NULL
  unsigned int index = (htab_hash_function(key) % MAGIC);
  struct htab_listitem * curr = t->arr_size[index];
  if(t->arr_size[index] != NULL) {  // if there is a list on ptr, go through it
    while(1) {
      if(!strcmp(curr->key,key))
        return curr;
      if(curr->next == NULL) // end of list..
        break;    
      curr = curr->next;
    }
	return NULL; // didnt find it 
  }
  else
	return NULL; // no list on ptr
}