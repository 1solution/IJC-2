// htab_free.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include "htab.h"

void htab_free(struct htab_t * t) { // free hash table itself
  free(t);
}