// htab_size.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include "htab.h"

unsigned long htab_size(struct htab_t * t) { // returns table size - c. of items
  return t->size;
}