// wordcount.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

// bugs - pocita to zkurveny mezery. orezat na delku slova m-1 a vypsat varovani. bacha, orezany slovo neni to stejny slovo jako to co bylo vlozeny.

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <ctype.h>
#include "htab.h"
#include "io.c"

void print(struct htab_listitem * item) { // function: print current cell
	printf("%s\t%i\n",item->key,item->data);	
}

int main() {

struct htab_t *hash = htab_init(MAGIC); // were looking for huge prime number to avoid as much collisions as possible
if(hash == NULL) {
	fprintf(stderr,"Could not malloc.\n");
	return 1;
}
FILE *fp = stdin;
char word[127] = {'\0'}; // word buffer

int n = 0; // counter of letters, because of last word has to be processed too
while((n = get_word(word,127,fp)) != EOF) { // until last word
  // processing one key at time STARTS

if(strlen(word) > 0) {
  struct htab_listitem * item = htab_lookup_add(hash, word);
  if(item == NULL) { // if returned NULL instead of pointer or pointer to newly created
    fprintf(stderr,"Couldn't enlist new item to hash table.\n");
    return 1;
  }  
}  
  // processing one key at time ENDS
  for (int i = 0; i < 127; i++) // clean word buffer
    word[i] = '\0'; 
}
if(n != 0) { // for last occurence of word, even if returns EOF but there is a word
	  // processing one key at time STARTS
if(strlen(word) > 0) {
  struct htab_listitem * item = htab_lookup_add(hash, word);
  if(item == NULL) { // if returned NULL instead of pointer or pointer to newly created
    fprintf(stderr,"Couldn't enlist new item to hash table.\n");
    return 1;
  }  
}  
  // processing one key at time ENDS
  for (int i = 0; i < 127; i++) // clean word buffer
    word[i] = '\0';	
}

struct htab_t *hash2 = htab_move(htab_bucket_count(hash),hash); // cvicna funkce move
if(hash2 == NULL) {
	fprintf(stderr,"Could not malloc new hash table.\n");
	return 1;	
}

htab_foreach(hash2,print);
htab_clear(hash2);
htab_free(hash2);
htab_free(hash); // free original table
fclose(fp);
return 0;

}