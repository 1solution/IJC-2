// htab_clear.c
// Řešení IJC-DU2, příklad 2/2, 8.4.2018
// Autor: Michal Plsek, xplsek03, FIT
// Přeloženo: gcc 6.4.0

#include <stdio.h>
#include <stdlib.h>
#include "htab.h"

void htab_clear(struct htab_t * t) { // free content of hash table
	for(unsigned int i = 0; i < MAGIC; i++) {
		struct htab_listitem * curr = t->arr_size[i];		
		if(curr != NULL) {
			while(curr->next != NULL) { // clean list
				struct htab_listitem * curr_next = curr->next;
				free(curr->key);
				free(curr);
				curr = curr_next;
			} // list is clean
		free(curr->key);
		free(curr); // clean first item
		}
	}
}